
// Everything IPC

#ifndef _EVERYTHING_IPC_H_
#define _EVERYTHING_IPC_H_

// C
#ifdef __cplusplus
extern "C" {
#endif

// WM_USER (send to the taskbar notification window)
// SendMessage(FindWindow(EVERYTHING_IPC_WNDCLASS,0),WM_USER,EVERYTHING_IPC_*,lParam)
// version format: major.minor.revision.build 
// example: 1.1.4.309
#define EVERYTHING_IPC_GET_MAJOR_VERSION		0 // int major_version = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_GET_MAJOR_VERSION,0);
#define EVERYTHING_IPC_GET_MINOR_VERSION		1 // int minor_version = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_GET_MINOR_VERSION,0);
#define EVERYTHING_IPC_GET_REVISION				2 // int revision = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_GET_REVISION,0);
#define EVERYTHING_IPC_GET_BUILD_NUMBER			3 // int build = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_GET_BUILD,0);
#define EVERYTHING_IPC_EXIT						4 // returns 1 if the program closes.

// uninstall options
#define EVERYTHING_IPC_DELETE_START_MENU_SHORTCUTS		100 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_DELETE_START_MENU_SHORTCUTS,0);
#define EVERYTHING_IPC_DELETE_QUICK_LAUNCH_SHORTCUT		101 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_DELETE_QUICK_LAUNCH_SHORTCUT,0);
#define EVERYTHING_IPC_DELETE_DESKTOP_SHORTCUT			102 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_DELETE_DESKTOP_SHORTCUT,0);
#define EVERYTHING_IPC_DELETE_FOLDER_CONTEXT_MENU		103 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_DELETE_FOLDER_CONTEXT_MENU,0);
#define EVERYTHING_IPC_DELETE_RUN_ON_SYSTEM_STARTUP		104 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_DELETE_RUN_ON_SYSTEM_STARTUP,0);
#define EVERYTHING_IPC_DELETE_URL_PROTOCOL				105 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_DELETE_URL_PROTOCOL,0);

// install options
#define EVERYTHING_IPC_CREATE_START_MENU_SHORTCUTS		200 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_CREATE_START_MENU_SHORTCUTS,0);
#define EVERYTHING_IPC_CREATE_QUICK_LAUNCH_SHORTCUT		201 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_CREATE_QUICK_LAUNCH_SHORTCUT,0);
#define EVERYTHING_IPC_CREATE_DESKTOP_SHORTCUT			202 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_CREATE_DESKTOP_SHORTCUT,0);
#define EVERYTHING_IPC_CREATE_FOLDER_CONTEXT_MENU		203 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_CREATE_FOLDER_CONTEXT_MENU,0);
#define EVERYTHING_IPC_CREATE_RUN_ON_SYSTEM_STARTUP		204 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_CREATE_RUN_ON_SYSTEM_STARTUP,0);
#define EVERYTHING_IPC_CREATE_URL_PROTOCOL				205 // SendMessage(hwnd,WM_USER,EVERYTHING_IPC_CREATE_URL_PROTOCOL,0);

// get option status; 0 = no, 1 = yes, 2 = indeterminate (partially installed)
#define EVERYTHING_IPC_IS_START_MENU_SHORTCUTS			300 // int ret = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_START_MENU_SHORTCUTS,0);
#define EVERYTHING_IPC_IS_QUICK_LAUNCH_SHORTCUT			301 // int ret = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_QUICK_LAUNCH_SHORTCUT,0);
#define EVERYTHING_IPC_IS_DESKTOP_SHORTCUT				302 // int ret = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_DESKTOP_SHORTCUT,0);
#define EVERYTHING_IPC_IS_FOLDER_CONTEXT_MENU			303 // int ret = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_FOLDER_CONTEXT_MENU,0);
#define EVERYTHING_IPC_IS_RUN_ON_SYSTEM_STARTUP			304 // int ret = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_RUN_ON_SYSTEM_STARTUP,0);
#define EVERYTHING_IPC_IS_URL_PROTOCOL					305 // int ret = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_URL_PROTOCOL,0);
#define EVERYTHING_IPC_IS_SERVICE						306 // int ret = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_SERVICE,0);

// indexing
#define EVERYTHING_IPC_IS_NTFS_DRIVE_INDEXED			400 // int is_indexed = (int)SendMessage(hwnd,WM_USER,EVERYTHING_IPC_IS_NTFS_DRIVE_INDEXED,drive_index); drive_index: 0-25 = A-Z

// object IDs
#define	EVERYTHING_ID_FILE_MENU							10001
#define	EVERYTHING_ID_EDIT_MENU							10002
#define	EVERYTHING_ID_SEARCH_MENU						10003
#define	EVERYTHING_ID_TOOLS_MENU						10004
#define	EVERYTHING_ID_HELP_MENU							10005
#define	EVERYTHING_ID_TOOLBAR							10006
#define	EVERYTHING_ID_SEARCH_EDIT						10007
#define	EVERYTHING_ID_FILTER							10008
#define	EVERYTHING_ID_RESULTS_HEADER					10009
#define	EVERYTHING_ID_STATUS							10010
#define EVERYTHING_ID_VIEW_ZOOM_MENU					10012
#define	EVERYTHING_ID_VIEW_MENU							10013
#define EVERYTHING_ID_VIEW_WINDOW_SIZE_MENU				10019
#define EVERYTHING_ID_RESULT_LIST						10020
#define EVERYTHING_ID_BOOKMARKS_MENU					10021
#define EVERYTHING_ID_VIEW_SORT_BY_MENU					10022
#define EVERYTHING_ID_VIEW_GOTO_MENU					10024
#define EVERYTHING_ID_VIEW_ONTOP_MENU					10025

// TRAY 
#define EVERYTHING_ID_TRAY_NEW_SEARCH_WINDOW			40001
#define EVERYTHING_ID_TRAY_CONNECT_TO_ETP_SERVER		40004
#define EVERYTHING_ID_TRAY_OPTIONS						40005
#define EVERYTHING_ID_TRAY_EXIT							40006
#define EVERYTHING_ID_TRAY_SHOW_SEARCH_WINDOW			40007
#define EVERYTHING_ID_TRAY_TOGGLE_SEARCH_WINDOW			40008

// FILE
#define EVERYTHING_ID_FILE_NEW_WINDOW					40010 
#define EVERYTHING_ID_FILE_CLOSE						40011 
#define EVERYTHING_ID_FILE_EXPORT						40012 
#define EVERYTHING_ID_FILE_EXIT							40013
#define EVERYTHING_ID_FILE_OPEN_FILELIST				40014
#define EVERYTHING_ID_FILE_CLOSE_FILELIST				40015

// EDIT
#define EVERYTHING_ID_EDIT_CUT							40020 
#define EVERYTHING_ID_EDIT_COPY							40021
#define EVERYTHING_ID_EDIT_PASTE						40022
#define EVERYTHING_ID_EDIT_SELECT_ALL					40023
#define EVERYTHING_ID_EDIT_INVERT_SELECTION				40029

// VIEW
#define EVERYTHING_ID_VIEW_ZOOM_IN						40030
#define EVERYTHING_ID_VIEW_ZOOM_OUT						40031
#define EVERYTHING_ID_VIEW_ZOOM_RESET					40032
#define EVERYTHING_ID_VIEW_TOGGLE_FULLSCREEN			40034
#define EVERYTHING_ID_VIEW_AUTO_FIT						40044
#define EVERYTHING_ID_VIEW_AUTO_SIZE_1					40045
#define EVERYTHING_ID_VIEW_AUTO_SIZE_2					40046
#define EVERYTHING_ID_VIEW_AUTO_SIZE_3					40047
#define EVERYTHING_ID_VIEW_REFRESH						40036
#define EVERYTHING_ID_VIEW_FILTERS						40035
#define EVERYTHING_ID_VIEW_SORT_BY_ASCENDING			40037
#define EVERYTHING_ID_VIEW_SORT_BY_DESCENDING			40038
#define EVERYTHING_ID_VIEW_STATUS_BAR					40039
#define EVERYTHING_ID_VIEW_GOTO_BACK					40040
#define EVERYTHING_ID_VIEW_GOTO_FORWARD					40041
#define EVERYTHING_ID_VIEW_ONTOP_NEVER					40042
#define EVERYTHING_ID_VIEW_ONTOP_ALWAYS					40043
#define EVERYTHING_ID_VIEW_ONTOP_WHILE_SEARCHING		40048
#define EVERYTHING_ID_VIEW_GOTO_HOME					40049
#define EVERYTHING_ID_VIEW_TOGGLE_LTR_RTL				40050
#define EVERYTHING_ID_VIEW_DETAILS						40051
#define EVERYTHING_ID_VIEW_MEDIUM_ICONS					40052
#define EVERYTHING_ID_VIEW_LARGE_ICONS					40053
#define EVERYTHING_ID_VIEW_EXTRA_LARGE_ICONS			40054

// SEARCH
#define	EVERYTHING_ID_SEARCH_TOGGLE_MATCH_CASE			40060
#define EVERYTHING_ID_SEARCH_TOGGLE_MATCH_WHOLE_WORD	40061
#define EVERYTHING_ID_SEARCH_TOGGLE_MATCH_PATH			40062
#define EVERYTHING_ID_SEARCH_TOGGLE_REGEX				40063
#define	EVERYTHING_ID_SEARCH_TOGGLE_MATCH_DIACRITICS	40066
#define EVERYTHING_ID_SEARCH_FILTER_ADD					40067
#define EVERYTHING_ID_SEARCH_FILTER_ORGANIZE			40068

// TOOLS
#define EVERYTHING_ID_TOOLS_CONNECT_TO_ETP_SERVER		40072
#define EVERYTHING_ID_TOOLS_DISCONNECT_FROM_ETP_SERVER	40073
#define EVERYTHING_ID_TOOLS_OPTIONS						40074
#define EVERYTHING_ID_TOOLS_CONSOLE						40075
#define EVERYTHING_ID_TOOLS_EDITOR						40076

// HELP
#define EVERYTHING_ID_HELP_VIEW_HELP_TOPICS				40080
#define EVERYTHING_ID_HELP_OPEN_EVERYTHING_WEBSITE		40081
#define EVERYTHING_ID_HELP_CHECK_FOR_UPDATES			40082
#define EVERYTHING_ID_HELP_ABOUT_EVERYTHING				40083
#define EVERYTHING_ID_HELP_SEARCH_SYNTAX				40084
#define EVERYTHING_ID_HELP_COMMAND_LINE_OPTIONS			40085
#define EVERYTHING_ID_HELP_REGEX_SYNTAX					40086

// bookmarks
#define EVERYTHING_ID_BOOKMARK_ADD						40090
#define EVERYTHING_ID_BOOKMARK_ORGANIZE					40091
#define EVERYTHING_ID_BOOKMARK_START					44000
#define EVERYTHING_ID_BOOKMARK_END						45000 // exclusive

#define EVERYTHING_ID_FILTER_START						45000
#define EVERYTHING_ID_FILTER_END						46000 // exclusive

#define EVERYTHING_ID_VIEW_GOTO_START					46000
#define EVERYTHING_ID_VIEW_GOTO_END						47000 // exclusive

// files
#define EVERYTHING_ID_FILE_OPEN							41000
#define EVERYTHING_ID_FILE_OPEN_NEW						41048
#define EVERYTHING_ID_FILE_OPEN_WITH					41049
#define EVERYTHING_ID_FILE_EDIT							41050
#define EVERYTHING_ID_FILE_PLAY							41051
#define EVERYTHING_ID_FILE_PRINT						41052
#define EVERYTHING_ID_FILE_PREVIEW						41053
#define EVERYTHING_ID_FILE_PRINT_TO						41054
#define EVERYTHING_ID_FILE_RUN_AS						41055
#define EVERYTHING_ID_FILE_OPEN_WITH_DEFAULT_VERB		41056
#define EVERYTHING_ID_FILE_OPEN_AND_CLOSE				41057
#define EVERYTHING_ID_FILE_EXPLORE_PATH					41002
#define EVERYTHING_ID_FILE_OPEN_PATH					41003
#define EVERYTHING_ID_FILE_DELETE						41004
#define EVERYTHING_ID_FILE_PERMANENTLY_DELETE			41005
#define EVERYTHING_ID_FILE_RENAME						41006
#define EVERYTHING_ID_FILE_COPY_FULL_PATH_AND_NAME		41007
#define EVERYTHING_ID_FILE_COPY_PATH					41008
#define EVERYTHING_ID_FILE_PROPERTIES					41009
#define EVERYTHING_ID_FILE_READ_EXTENDED_INFORMATION	41064
#define EVERYTHING_ID_FILE_CREATE_SHORTCUT				41065
#define EVERYTHING_ID_FILE_SET_RUN_COUNT				41068

// result list
#define EVERYTHING_ID_RESULT_LIST_EXPLORE				41001
#define EVERYTHING_ID_RESULT_LIST_FOCUS					41010
#define EVERYTHING_ID_RESULT_LIST_AUTOFIT_COLUMNS		41012
#define EVERYTHING_ID_RESULT_LIST_DOWN					41018
#define EVERYTHING_ID_RESULT_LIST_UP					41019
#define EVERYTHING_ID_RESULT_LIST_PAGE_UP				41020
#define EVERYTHING_ID_RESULT_LIST_PAGE_DOWN				41021
#define EVERYTHING_ID_RESULT_LIST_START					41022
#define EVERYTHING_ID_RESULT_LIST_END					41023
#define EVERYTHING_ID_RESULT_LIST_DOWN_EXTEND			41024
#define EVERYTHING_ID_RESULT_LIST_UP_EXTEND				41025
#define EVERYTHING_ID_RESULT_LIST_PAGE_UP_EXTEND		41026
#define EVERYTHING_ID_RESULT_LIST_PAGE_DOWN_EXTEND		41027
#define EVERYTHING_ID_RESULT_LIST_START_EXTEND			41028
#define EVERYTHING_ID_RESULT_LIST_END_EXTEND			41029
#define EVERYTHING_ID_RESULT_LIST_FOCUS_DOWN			41030
#define EVERYTHING_ID_RESULT_LIST_FOCUS_UP				41031
#define EVERYTHING_ID_RESULT_LIST_FOCUS_PAGE_UP			41032
#define EVERYTHING_ID_RESULT_LIST_FOCUS_PAGE_DOWN		41033
#define EVERYTHING_ID_RESULT_LIST_FOCUS_START			41034
#define EVERYTHING_ID_RESULT_LIST_FOCUS_END				41035
#define EVERYTHING_ID_RESULT_LIST_SCROLL_LEFT			41036
#define EVERYTHING_ID_RESULT_LIST_SCROLL_RIGHT			41037
#define EVERYTHING_ID_RESULT_LIST_SCROLL_PAGE_LEFT		41038
#define EVERYTHING_ID_RESULT_LIST_SCROLL_PAGE_RIGHT		41039
#define EVERYTHING_ID_RESULT_LIST_SELECT_FOCUS			41040
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_FOCUS_SELECTION	41041
#define EVERYTHING_ID_RESULT_LIST_CONTEXT_MENU			41046
#define EVERYTHING_ID_RESULT_LIST_FOCUS_DOWN_EXTEND			41058
#define EVERYTHING_ID_RESULT_LIST_FOCUS_UP_EXTEND			41059
#define EVERYTHING_ID_RESULT_LIST_FOCUS_PAGE_UP_EXTEND		41060
#define EVERYTHING_ID_RESULT_LIST_FOCUS_PAGE_DOWN_EXTEND	41061
#define EVERYTHING_ID_RESULT_LIST_FOCUS_START_EXTEND		41062
#define EVERYTHING_ID_RESULT_LIST_FOCUS_END_EXTEND			41063
#define EVERYTHING_ID_RESULT_LIST_AUTOFIT				41066
#define EVERYTHING_ID_RESULT_LIST_COPY_CSV				41067

#define EVERYTHING_ID_RESULT_LIST_LEFT_EXTEND			41070
#define EVERYTHING_ID_RESULT_LIST_RIGHT_EXTEND			41071
#define EVERYTHING_ID_RESULT_LIST_FOCUS_LEFT_EXTEND		41072
#define EVERYTHING_ID_RESULT_LIST_FOCUS_RIGHT_EXTEND	41073

#define EVERYTHING_ID_RESULT_LIST_SORT_BY_NAME				41300
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_PATH				41301
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_SIZE				41302
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_EXTENSION			41303
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_TYPE				41304
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_DATE_MODIFIED		41305
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_DATE_CREATED		41306
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_ATTRIBUTES		41307
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_FILE_LIST_FILENAME	41308
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_RUN_COUNT			41309
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_DATE_RECENTLY_CHANGED		41310
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_DATE_ACCESSED		41311
#define EVERYTHING_ID_RESULT_LIST_SORT_BY_DATE_RUN			41312

#define EVERYTHING_ID_RESULT_LIST_TOGGLE_NAME_COLUMN			41400
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_PATH_COLUMN			41401
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_SIZE_COLUMN			41402
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_EXTENSION_COLUMN		41403
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_TYPE_COLUMN			41404
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_DATE_MODIFIED_COLUMN	41405
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_DATE_CREATED_COLUMN	41406
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_ATTRIBUTES_COLUMN		41407
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_FILE_LIST_FILENAME_COLUMN		41408
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_RUN_COUNT_COLUMN				41409
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_DATE_RECENTLY_CHANGED_COLUMN		41410
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_DATE_ACCESSED_COLUMN			41411
#define EVERYTHING_ID_RESULT_LIST_TOGGLE_DATE_RUN_COLUMN				41412

#define EVERYTHING_ID_RESULT_LIST_SIZE_NAME_COLUMN_TO_FIT			41600
#define EVERYTHING_ID_RESULT_LIST_SIZE_PATH_COLUMN_TO_FIT			41601
#define EVERYTHING_ID_RESULT_LIST_SIZE_SIZE_COLUMN_TO_FIT			41602
#define EVERYTHING_ID_RESULT_LIST_SIZE_EXTENSION_COLUMN_TO_FIT		41603
#define EVERYTHING_ID_RESULT_LIST_SIZE_TYPE_COLUMN_TO_FIT			41604
#define EVERYTHING_ID_RESULT_LIST_SIZE_DATE_MODIFIED_COLUMN_TO_FIT	41605
#define EVERYTHING_ID_RESULT_LIST_SIZE_DATE_CREATED_COLUMN_TO_FIT	41606
#define EVERYTHING_ID_RESULT_LIST_SIZE_ATTRIBUTES_COLUMN_TO_FIT		41607
#define EVERYTHING_ID_RESULT_LIST_SIZE_FILE_LIST_FILENAME_COLUMN_TO_FIT		41608
#define EVERYTHING_ID_RESULT_LIST_SIZE_RUN_COUNT_COLUMN_TO_FIT		41609
#define EVERYTHING_ID_RESULT_LIST_SIZE_DATE_RECENTLY_CHANGED_COLUMN_TO_FIT	41610
#define EVERYTHING_ID_RESULT_LIST_SIZE_DATE_ACCESSED_COLUMN_TO_FIT	41611
#define EVERYTHING_ID_RESULT_LIST_SIZE_DATE_RUN_COLUMN_TO_FIT		41612

#define EVERYTHING_ID_FILE_CUSTOM_VERB01				41500
#define EVERYTHING_ID_FILE_CUSTOM_VERB02				41501
#define EVERYTHING_ID_FILE_CUSTOM_VERB03				41502
#define EVERYTHING_ID_FILE_CUSTOM_VERB04				41503
#define EVERYTHING_ID_FILE_CUSTOM_VERB05				41504
#define EVERYTHING_ID_FILE_CUSTOM_VERB06				41505
#define EVERYTHING_ID_FILE_CUSTOM_VERB07				41506
#define EVERYTHING_ID_FILE_CUSTOM_VERB08				41507
#define EVERYTHING_ID_FILE_CUSTOM_VERB09				41508
#define EVERYTHING_ID_FILE_CUSTOM_VERB10				41509
#define EVERYTHING_ID_FILE_CUSTOM_VERB11				41510
#define EVERYTHING_ID_FILE_CUSTOM_VERB12				41511

// search
#define EVERYTHING_ID_SEARCH_EDIT_FOCUS						42000
#define EVERYTHING_ID_SEARCH_EDIT_WORD_DELETE_TO_START		42019
#define	EVERYTHING_ID_SEARCH_EDIT_AUTO_COMPLETE				42020
#define EVERYTHING_ID_SEARCH_EDIT_SHOW_SEARCH_HISTORY		42021
#define EVERYTHING_ID_SEARCH_EDIT_SHOW_ALL_SEARCH_HISTORY	42022

#define EVERYTHING_ID_TRAY_EDITOR						41700
#define EVERYTHING_ID_TRAY_OPEN_FILELIST				41701

// find the everything IPC window
#define EVERYTHING_IPC_WNDCLASS			TEXT("EVERYTHING_TASKBAR_NOTIFICATION")

// this global window message is sent to all top level windows when everything starts.
#define EVERYTHING_IPC_CREATED			TEXT("EVERYTHING_IPC_CREATED")

// search flags for querys
#define EVERYTHING_IPC_MATCHCASE		0x00000001	// match case
#define EVERYTHING_IPC_MATCHWHOLEWORD	0x00000002	// match whole word
#define EVERYTHING_IPC_MATCHPATH		0x00000004	// include paths in search
#define EVERYTHING_IPC_REGEX			0x00000008	// enable regex
#define EVERYTHING_IPC_MATCHACCENTS		0x00000010	// match diacritic marks

// item flags
#define EVERYTHING_IPC_FOLDER			0x00000001	// The item is a folder. (its a file if not set)
#define EVERYTHING_IPC_DRIVE			0x00000002	// The folder is a drive. Path will be an empty string. 
													// (will also have the folder bit set)

// the WM_COPYDATA message for a query.
#define EVERYTHING_IPC_COPYDATAQUERYA	1
#define EVERYTHING_IPC_COPYDATAQUERYW	2

// all results
#define EVERYTHING_IPC_ALLRESULTS		0xFFFFFFFF // all results

// macro to get the filename of an item
#define EVERYTHING_IPC_ITEMFILENAMEA(list,item) (CHAR *)((CHAR *)(list) + ((EVERYTHING_IPC_ITEMA *)(item))->filename_offset)
#define EVERYTHING_IPC_ITEMFILENAMEW(list,item) (WCHAR *)((CHAR *)(list) + ((EVERYTHING_IPC_ITEMW *)(item))->filename_offset)

// macro to get the path of an item
#define EVERYTHING_IPC_ITEMPATHA(list,item) (CHAR *)((CHAR *)(list) + ((EVERYTHING_IPC_ITEMW *)(item))->path_offset)
#define EVERYTHING_IPC_ITEMPATHW(list,item) (WCHAR *)((CHAR *)(list) + ((EVERYTHING_IPC_ITEMW *)(item))->path_offset)

#pragma pack (push,1)

//
// Varible sized query struct sent to everything.
//
// sent in the form of a WM_COPYDAYA message with EVERYTHING_IPC_COPYDATAQUERY as the 
// dwData member in the COPYDATASTRUCT struct.
// set the lpData member of the COPYDATASTRUCT struct to point to your EVERYTHING_IPC_QUERY struct.
// set the cbData member of the COPYDATASTRUCT struct to the size of the 
// EVERYTHING_IPC_QUERY struct minus the size of a CHAR plus the length of the search string in bytes plus 
// one CHAR for the null terminator.
//
// NOTE: to determine the size of this structure use 
// ASCII: sizeof(EVERYTHING_IPC_QUERYA) - sizeof(CHAR) + strlen(search_string)*sizeof(CHAR) + sizeof(CHAR)
// UNICODE: sizeof(EVERYTHING_IPC_QUERYW) - sizeof(WCHAR) + unicode_length_in_wchars(search_string)*sizeof(WCHAR) + sizeof(WCHAR)
//
// NOTE: Everything will only do one query per window.
// Sending another query when a query has not completed 
// will cancel the old query and start the new one. 
//
// Everything will send the results to the reply_hwnd in the form of a 
// WM_COPYDAYA message with the dwData value you specify.
// 
// Everything will return TRUE if successful.
// returns FALSE if not supported.
//
// If you query with EVERYTHING_IPC_COPYDATAQUERYW, the results sent from Everything will be Unicode.
//

typedef struct EVERYTHING_IPC_QUERYW
{
	// the window that will receive the new results.
	// only 32bits are required to store a window handle. (even on x64)
	DWORD reply_hwnd;
	
	// the value to set the dwData member in the COPYDATASTRUCT struct 
	// sent by Everything when the query is complete.
	DWORD reply_copydata_message;
	
	// search flags (see EVERYTHING_MATCHCASE | EVERYTHING_MATCHWHOLEWORD | EVERYTHING_MATCHPATH)
	DWORD search_flags; 
	
	// only return results after 'offset' results (0 to return the first result)
	// useful for scrollable lists
	DWORD offset; 
	
	// the number of results to return 
	// zero to return no results
	// EVERYTHING_IPC_ALLRESULTS to return ALL results
	DWORD max_results;

	// null terminated string. arbitrary sized search_string buffer.
	WCHAR search_string[1];
	
}EVERYTHING_IPC_QUERYW;

// ASCII version
typedef struct EVERYTHING_IPC_QUERYA
{
	// the window that will receive the new results.
	// only 32bits are required to store a window handle. (even on x64)
	DWORD reply_hwnd;
	
	// the value to set the dwData member in the COPYDATASTRUCT struct 
	// sent by Everything when the query is complete.
	DWORD reply_copydata_message;
	
	// search flags (see EVERYTHING_MATCHCASE | EVERYTHING_MATCHWHOLEWORD | EVERYTHING_MATCHPATH)
	DWORD search_flags; 
	
	// only return results after 'offset' results (0 to return the first result)
	// useful for scrollable lists
	DWORD offset; 
	
	// the number of results to return 
	// zero to return no results
	// EVERYTHING_IPC_ALLRESULTS to return ALL results
	DWORD max_results;

	// null terminated string. arbitrary sized search_string buffer.
	CHAR search_string[1];
	
}EVERYTHING_IPC_QUERYA;

//
// Varible sized result list struct received from Everything.
//
// Sent in the form of a WM_COPYDATA message to the hwnd specifed in the 
// EVERYTHING_IPC_QUERY struct.
// the dwData member of the COPYDATASTRUCT struct will match the sent
// reply_copydata_message member in the EVERYTHING_IPC_QUERY struct.
// 
// make a copy of the data before returning.
//
// return TRUE if you processed the WM_COPYDATA message.
//

typedef struct EVERYTHING_IPC_ITEMW
{
	// item flags
	DWORD flags;

	// The offset of the filename from the beginning of the list structure.
	// (wchar_t *)((char *)everything_list + everythinglist->name_offset)
	DWORD filename_offset;

	// The offset of the filename from the beginning of the list structure.
	// (wchar_t *)((char *)everything_list + everythinglist->path_offset)
	DWORD path_offset;
	
}EVERYTHING_IPC_ITEMW;

typedef struct EVERYTHING_IPC_ITEMA
{
	// item flags
	DWORD flags;

	// The offset of the filename from the beginning of the list structure.
	// (char *)((char *)everything_list + everythinglist->name_offset)
	DWORD filename_offset;

	// The offset of the filename from the beginning of the list structure.
	// (char *)((char *)everything_list + everythinglist->path_offset)
	DWORD path_offset;
	
}EVERYTHING_IPC_ITEMA;

typedef struct EVERYTHING_IPC_LISTW
{
	// the total number of folders found.
	DWORD totfolders;
	
	// the total number of files found.
	DWORD totfiles;
	
	// totfolders + totfiles
	DWORD totitems;
	
	// the number of folders available.
	DWORD numfolders;
	
	// the number of files available.
	DWORD numfiles;
	
	// the number of items available.
	DWORD numitems;

	// index offset of the first result in the item list.
	DWORD offset;
	
	// arbitrary sized item list. 
	// use numitems to determine the actual number of items available.
	EVERYTHING_IPC_ITEMW items[1];
	
}EVERYTHING_IPC_LISTW;

typedef struct EVERYTHING_IPC_LISTA
{
	// the total number of folders found.
	DWORD totfolders;
	
	// the total number of files found.
	DWORD totfiles;
	
	// totfolders + totfiles
	DWORD totitems;
	
	// the number of folders available.
	DWORD numfolders;
	
	// the number of files available.
	DWORD numfiles;
	
	// the number of items available.
	DWORD numitems;

	// index offset of the first result in the item list.
	DWORD offset;
	
	// arbitrary sized item list. 
	// use numitems to determine the actual number of items available.
	EVERYTHING_IPC_ITEMA items[1];
	
}EVERYTHING_IPC_LISTA;

#pragma pack (pop)

#ifdef UNICODE
#define EVERYTHING_IPC_COPYDATAQUERY	EVERYTHING_IPC_COPYDATAQUERYW
#define EVERYTHING_IPC_ITEMFILENAME		EVERYTHING_IPC_ITEMFILENAMEW
#define EVERYTHING_IPC_ITEMPATH			EVERYTHING_IPC_ITEMPATHW
#define EVERYTHING_IPC_QUERY			EVERYTHING_IPC_QUERYW
#define EVERYTHING_IPC_ITEM				EVERYTHING_IPC_ITEMW
#define EVERYTHING_IPC_LIST				EVERYTHING_IPC_LISTW
#else
#define EVERYTHING_IPC_COPYDATAQUERY	EVERYTHING_IPC_COPYDATAQUERYA
#define EVERYTHING_IPC_ITEMFILENAME		EVERYTHING_IPC_ITEMFILENAMEA
#define EVERYTHING_IPC_ITEMPATH			EVERYTHING_IPC_ITEMPATHA
#define EVERYTHING_IPC_QUERY			EVERYTHING_IPC_QUERYA
#define EVERYTHING_IPC_ITEM				EVERYTHING_IPC_ITEMA
#define EVERYTHING_IPC_LIST				EVERYTHING_IPC_LISTA
#endif

// end extern C
#ifdef __cplusplus
}
#endif

#endif // _EVERYTHING_H_

